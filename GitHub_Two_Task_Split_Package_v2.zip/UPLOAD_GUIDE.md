# GitHub 上传说明

建议团队仓库结构：

```text
contact_homework/
├── README.md                 # 团队项目总说明（保留现有文件）
├── index.html                # Task A
├── script.js                 # Task A
├── style.css                 # Task A
└── task_b_contact_backend/   # Task B
    ├── app/
    ├── tests/
    ├── docs/
    ├── requirements.txt
    └── README.md
```

## 上传 Task A
将 `Task_A_Frontend` 中的 `index.html`、`script.js`、`style.css` 上传到仓库根目录。`README_TASK_A.md` 可按需改名或合并到团队 README。

## 上传 Task B
将 `Task_B_Backend` 中的整个 `task_b_contact_backend` 文件夹上传到仓库根目录。

## 注意
- 两部分必须来自同一套最终整合代码。
- 不上传 `contacts.db`、`.venv`、`__pycache__`、`.pyc`。
- 如果仓库已有 README.md，不要覆盖；把说明合并进去。
- 上传后分别提交并检查文件路径。
