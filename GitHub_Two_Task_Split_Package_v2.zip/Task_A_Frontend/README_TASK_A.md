# Task A - Frontend

前端部分包含：
- `index.html`：页面结构
- `style.css`：页面样式
- `script.js`：页面交互及后端 API 调用

## 运行方式

在项目根目录（包含 `index.html` 的目录）打开 PowerShell：

```powershell
python -m http.server 5500
```

浏览器访问：

`http://127.0.0.1:5500`

请同时启动 Task B FastAPI 后端。前端 API 地址及跨域配置应与后端实际配置保持一致。
